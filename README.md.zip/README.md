# TPBinomePython2023
TP en binome avec Julien ISITECH 2023
---------------
Sujet tiré : Fichier ZIP // Sujets choisis : FTP & KIVY
---------------

Librairie a installé : 

pip install kivy
pip install pyftpdlib

Démarrer l'application : 

- Assurez vous d'avoir bien démarrer le script ftpserver.py
pour Démarrer le serveur FTP
- Ensuite vous pouvez démarrer le script main.py pour démarrer l'application
- Sélectionner un fichier en double cliquant dessus 
- a partir de la il est possible d'utiliser les boutons en bas de l'ecran pour envoyer le fichier vers le serveur ftp ou le décomprésser/comprésser en fonction de son état actuel
- Les fichier envoyer vers le serveurs ftp peuvent être retrouver dans le dossier get_ftp
- Enfin le bouton Quit sert a quittez l'application